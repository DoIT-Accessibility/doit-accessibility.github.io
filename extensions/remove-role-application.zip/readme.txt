This Remove role=application extension temporarily removes role=application from all elements, except those inside iframes or shadowDOMS.

1. Extract this zip file to a folder on your computer.
2. Open Edge or Chrome.
3. In the address bar, type chrome://extensions and press Enter.
4. Check the "Developer mode" checkbox/toggle button.
5. Click the "Load unpacked" button.
6. Select the folder you extracted in step 1.
7. Whenever you are asked if you want to turn off extensions in developer mode, click Not Now.
8. Click on the extension icon to run it.

This extension is provided without warranty and could have unexpected side effects; please use it only at your own risk.

https://iitaa.dev/extensions/extensions/remove-role-application.html