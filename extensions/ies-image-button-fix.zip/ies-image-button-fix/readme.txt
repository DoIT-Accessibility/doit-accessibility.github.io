IES Image Button Fix
An update to Google Chrome and Microsoft Edge (around version 131) caused these browsers to stop recognizing alt text on buttons with type="IMAGE" in all caps.
This browser extension temporarily fixes this issue by resetting all input type="IMAGE" (uppercase) to type="image" (lowercase).
IMPORTANT: This extension is provided without warranty and could have unexpected side effects; please use it only at your own risk.

Instructions
1. Download https://doit-accessibility.github.io/extensions/ies-image-button-fix.zip.
2. Extract the zip file to a folder on your computer.
3. Open Edge or Chrome.
4. In the address bar, type chrome://extensions and press Enter.
5. Check the "Developer mode" checkbox/toggle button.
6. Click the "Load unpacked" button.
7. Select the folder you extracted in step 2.
8. Whenever you are asked if you want to turn off extensions in developer mode, click Not Now.
9. When this problem is fixed in Chrome/Edge or IES, remove this extension.

Note
This extension is configured only to run on the following web sites. It will not run on other URLs:
* doit-accessibility.github.io
* vt2-perf-ies.illinois.gov
* ies-ext.illinois.gov
* wp.illinois.gov (added 6/5/2025)

Questions
Please email DoIT.Accessibility@Illinois.gov
https://doit-accessibility.github.io/extensions/ies-image-button-fix.html