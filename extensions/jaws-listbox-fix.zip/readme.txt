A recent update to JAWS and/or Chromium has caused a bug with listboxes (select elements with size attribute greater than 1). In Chrome or Edge, JAWS incorrectly clicks the wrong button after making a selection from the listbox. (NVDA does not have this problem, and JAWS does not have it with Firefox.)

This JAWS Listbox Fix browser extension temporarily fixes this issue by setting the multiple attribute on selects with size greater than 1 and removing the multiple attribute while the listbox has focus (to prevent multiple selections).

1. Extract this zip file to a folder on your computer.
2. Open Edge or Chrome.
3. In the address bar, type chrome://extensions and press Enter.
4. Check the "Developer mode" checkbox/toggle button.
5. Click the "Load unpacked" button.
6. Select the folder you extracted in step 1.
7. Whenever you are asked if you want to turn off extensions in developer mode, click Not Now.
8. When this problem is fixed in Chrome/Edge or IES, remove this extension.

This extension is provided without warranty and could have unexpected side effects; please use it only at your own risk.

https://iitaa.dev/extensions/extensions/jaws-listbox-fix.html